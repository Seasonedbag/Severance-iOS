Severance v4 — Universal offline PWA

Install (recommended):
1. Serve the folder and open index_pwa.html in Safari (e.g. http://192.168.0.249:8080/Severance_PWA_v3/index_pwa.html)
2. Tap Share → Add to Home Screen
3. Open from Home Screen. Wait a few seconds for initial cache to complete.
4. You can stop the server — app will load offline.

Notes: Service worker caches relative assets so the PWA works regardless of folder path.
